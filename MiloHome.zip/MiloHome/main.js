function showAnswer() {
    document.getElementById("answerBox").classList.remove("hidden");
  }
  